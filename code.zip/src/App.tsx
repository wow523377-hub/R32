import { useState, useEffect } from 'react';
import Stars from './components/Stars';
import LearnScreen from './components/LearnScreen';
import ProfileScreen from './components/ProfileScreen';
import Settings from './components/Settings';
import WordModal from './components/WordModal';
import Sidebar from './components/Sidebar';
import { initDB, idbClear, startAutoSave, stopAutoSave } from './db';

type Screen = 'learn' | 'profile' | 'settings';
type ManualMode = 'auto' | 'en-ru' | 'ru-en' | 'context';

export default function App() {
  const [screen, setScreen] = useState<Screen>('learn');
  const [ready, setReady] = useState(false);
  const [modalWordId, setModalWordId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [manualMode, setManualMode] = useState<ManualMode>('auto');

  useEffect(() => {
    initDB().then(() => {
      setReady(true);
      startAutoSave();
    }).catch(err => {
      console.error('Boot error:', err);
      setReady(true);
    });
    
    return () => stopAutoSave();
  }, []);

  const handleReset = async () => {
    if (!confirm('Сбросить весь прогресс?')) return;
    try {
      await idbClear('words');
      await idbClear('attempts');
      await idbClear('sessions');
      await idbClear('dailyActivity');
      await idbClear('userStats');
      await initDB();
      window.location.reload();
    } catch (err) {
      console.error('Reset failed:', err);
      alert('Не удалось сбросить прогресс. Попробуйте ещё раз.');
    }
  };

  if (!ready) {
    return (
      <div className="h-full flex items-center justify-center bg-bg-deep">
        <div className="text-text-muted text-sm">Загрузка...</div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <Stars />

      {/* Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onOpen={() => setSidebarOpen(true)}
        onClose={() => setSidebarOpen(false)}
        activeMode={manualMode}
        onModeChange={setManualMode}
        onNavigate={setScreen}
        currentScreen={screen}
      />

      {/* Header */}
      <header className="relative z-10 px-4 pt-3 pb-2 flex items-center justify-between">
        <button
          onClick={() => setSidebarOpen(true)}
          className="w-10 h-10 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-surface transition-colors"
          aria-label="Open menu"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M3 12h18M3 6h18M3 18h18" />
          </svg>
        </button>
        
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-accent-2 flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1A1508" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2l2.5 6.5L21 10l-5 4.5 1.5 7L12 18l-5.5 3.5L8 14.5 3 10l6.5-1.5z" />
            </svg>
          </div>
          <span className="font-serif text-lg font-medium">31.Dec</span>
        </div>
        
        <button onClick={handleReset} className="w-10 h-10 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-surface transition-colors" title="Сбросить прогресс">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" />
          </svg>
        </button>
      </header>

      {/* Main */}
      <main className="relative z-10 flex-1 overflow-y-auto pb-20">
        <div className="w-[95%] max-w-md mx-auto px-2 py-4">
          {screen === 'learn' && <LearnScreen manualMode={manualMode} onModeChange={setManualMode} />}
          {screen === 'profile' && <ProfileScreen onOpenWord={setModalWordId} />}
          {screen === 'settings' && <Settings />}
        </div>
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 px-3 pb-3 bg-gradient-to-t from-bg-deep via-bg-deep/95 to-transparent">
        <div className="max-w-md mx-auto flex gap-1 bg-bg-surface border border-border rounded-xl p-1">
          <button
            onClick={() => setScreen('learn')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              screen === 'learn' ? 'bg-accent text-accent-ink' : 'text-text-secondary'
            }`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
            </svg>
            Учить
          </button>
          <button
            onClick={() => setScreen('profile')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              screen === 'profile' ? 'bg-accent text-accent-ink' : 'text-text-secondary'
            }`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
            </svg>
            Профиль
          </button>
          <button
            onClick={() => setScreen('settings')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              screen === 'settings' ? 'bg-accent text-accent-ink' : 'text-text-secondary'
            }`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
            Настройки
          </button>
        </div>
      </nav>

      <WordModal wordId={modalWordId} onClose={() => setModalWordId(null)} />
    </div>
  );
}
