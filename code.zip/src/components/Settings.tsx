import { useState, useEffect } from 'react';
import { idbGet, idbPut } from '../db';

interface Settings {
  pomodoroEnabled: boolean;
  pomodoroWorkTime: number;
  pomodoroBreakTime: number;
  learningMethods: {
    auto: boolean;
    enToRu: boolean;
    ruToEn: boolean;
    context: boolean;
  };
  soundEnabled: boolean;
  ttsEnabled: boolean;
}

const DEFAULT_SETTINGS: Settings = {
  pomodoroEnabled: false,
  pomodoroWorkTime: 25,
  pomodoroBreakTime: 5,
  learningMethods: {
    auto: true,
    enToRu: true,
    ruToEn: true,
    context: true
  },
  soundEnabled: true,
  ttsEnabled: true
};

export default function Settings() {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const saved = await idbGet('settings', 'userPreferences');
      if (saved) {
        setSettings({ ...DEFAULT_SETTINGS, ...saved });
      }
    } catch (err) {
      console.warn('Failed to load settings:', err);
    }
  };

  const saveSettings = async (newSettings: Settings) => {
    setSettings(newSettings);
    try {
      await idbPut('settings', { key: 'userPreferences', ...newSettings });
      setSaved(true);
    } catch (err) {
      console.warn('Failed to save settings:', err);
      setSaved(false);
    }
  };

  // Очистка timeout при размонтировании
  useEffect(() => {
    if (!saved) return;
    const timer = setTimeout(() => setSaved(false), 2000);
    return () => clearTimeout(timer);
  }, [saved]);

  const updateSetting = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings(prev => {
      const newSettings = { ...prev, [key]: value };
      saveSettings(newSettings);
      return newSettings;
    });
  };

  const updateLearningMethod = (method: keyof Settings['learningMethods'], enabled: boolean) => {
    setSettings(prev => {
      const newSettings = {
        ...prev,
        learningMethods: {
          ...prev.learningMethods,
          [method]: enabled
        }
      };
      saveSettings(newSettings);
      return newSettings;
    });
  };

  return (
    <div className="animate-fadeIn">
      <h1 className="font-serif text-3xl font-medium mb-6">Настройки</h1>

      {/* Pomodoro */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold tracking-widest uppercase text-text-muted mb-4">
          Метод Помодоро
        </h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">Включить Помодоро</div>
              <div className="text-sm text-text-secondary mt-1">
                25 мин работы / 5 мин отдыха
              </div>
            </div>
            <button
              onClick={() => updateSetting('pomodoroEnabled', !settings.pomodoroEnabled)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.pomodoroEnabled ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.pomodoroEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {settings.pomodoroEnabled && (
            <>
              <div className="p-4 bg-bg-elevated rounded-xl border border-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">Время работы</div>
                  <div className="font-mono text-accent">{settings.pomodoroWorkTime} мин</div>
                </div>
                <input
                  type="range"
                  min="15"
                  max="60"
                  step="5"
                  value={settings.pomodoroWorkTime}
                  onChange={(e) => updateSetting('pomodoroWorkTime', parseInt(e.target.value))}
                  className="w-full"
                />
              </div>

              <div className="p-4 bg-bg-elevated rounded-xl border border-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">Время отдыха</div>
                  <div className="font-mono text-accent">{settings.pomodoroBreakTime} мин</div>
                </div>
                <input
                  type="range"
                  min="3"
                  max="15"
                  step="1"
                  value={settings.pomodoroBreakTime}
                  onChange={(e) => updateSetting('pomodoroBreakTime', parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
            </>
          )}
        </div>
      </section>

      {/* Learning Methods */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold tracking-widest uppercase text-text-muted mb-4">
          Методы обучения
        </h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">Auto (FSRS)</div>
              <div className="text-sm text-text-secondary mt-1">
                Автоматический выбор режима
              </div>
            </div>
            <button
              onClick={() => updateLearningMethod('auto', !settings.learningMethods.auto)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.learningMethods.auto ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.learningMethods.auto ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">EN → RU</div>
              <div className="text-sm text-text-secondary mt-1">
                Английский → Русский
              </div>
            </div>
            <button
              onClick={() => updateLearningMethod('enToRu', !settings.learningMethods.enToRu)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.learningMethods.enToRu ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.learningMethods.enToRu ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">RU → EN</div>
              <div className="text-sm text-text-secondary mt-1">
                Русский → Английский
              </div>
            </div>
            <button
              onClick={() => updateLearningMethod('ruToEn', !settings.learningMethods.ruToEn)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.learningMethods.ruToEn ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.learningMethods.ruToEn ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">Context</div>
              <div className="text-sm text-text-secondary mt-1">
                Заполнение пропусков
              </div>
            </div>
            <button
              onClick={() => updateLearningMethod('context', !settings.learningMethods.context)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.learningMethods.context ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.learningMethods.context ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Audio & TTS */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold tracking-widest uppercase text-text-muted mb-4">
          Звук и озвучка
        </h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">Звуковые эффекты</div>
              <div className="text-sm text-text-secondary mt-1">
                Звуки при правильных/неправильных ответах
              </div>
            </div>
            <button
              onClick={() => updateSetting('soundEnabled', !settings.soundEnabled)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.soundEnabled ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-bg-elevated rounded-xl border border-border">
            <div>
              <div className="font-medium">Озвучка слов (TTS)</div>
              <div className="text-sm text-text-secondary mt-1">
                Произношение английских слов
              </div>
            </div>
            <button
              onClick={() => updateSetting('ttsEnabled', !settings.ttsEnabled)}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.ttsEnabled ? 'bg-accent' : 'bg-bg-surface-2'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.ttsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Save indicator */}
      {saved && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 px-6 py-3 bg-success/20 border border-success/30 rounded-xl text-success text-sm font-medium animate-fadeIn">
          ✓ Настройки сохранены
        </div>
      )}
    </div>
  );
}
