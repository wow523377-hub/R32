import { useState, useEffect } from 'react';
import { WordRecord, AttemptRecord, idbGet, idbGetAllByIndex } from '../db';
import { createInitialFSRSState, isMastered, retrievability } from '../utils/fsrs';

function modeLabel(mode: string): string {
  if (mode === 'enToRu') return 'EN → RU';
  if (mode === 'ruToEn') return 'RU → EN';
  return 'Context';
}

export default function WordModal({ wordId, onClose }: { wordId: string | null; onClose: () => void }) {
  const [word, setWord] = useState<WordRecord | null>(null);
  const [attempts, setAttempts] = useState<AttemptRecord[]>([]);

  useEffect(() => {
    if (!wordId) return;
    let cancelled = false;
    (async () => {
      try {
        const w = await idbGet('words', wordId) as WordRecord;
        const a = await idbGetAllByIndex('attempts', 'byWord', wordId) as AttemptRecord[];
        a.sort((x, y) => y.timestamp - x.timestamp);
        if (!cancelled) {
          setWord(w);
          setAttempts(a);
        }
      } catch (err) {
        console.warn('Failed to load word details:', err);
      }
    })();
    return () => { cancelled = true; };
  }, [wordId]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  if (!wordId || !word) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end justify-center animate-fadeIn"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="bg-bg-base border-t border-white/10 rounded-t-xl w-full max-w-md max-h-[80vh] overflow-y-auto p-4">
        <div className="flex justify-between items-center mb-3">
          <h2 className="font-serif text-lg font-medium">{word.english}</h2>
          <button onClick={onClose} className="w-7 h-7 rounded-lg bg-bg-elevated flex items-center justify-center text-text-muted hover:text-text-primary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M18 6L6 18" /><path d="M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="text-sm text-text-secondary mb-3">{word.russian} · {word.category}</div>

        {/* FSRS Stats */}
        <div className="bg-bg-elevated rounded-lg p-3 mb-3">
          <div className="text-[9px] tracking-widest uppercase text-text-muted mb-2">FSRS</div>
          {(['enToRu', 'ruToEn', 'context'] as const).map(m => {
            const s = word.srs?.[m] || createInitialFSRSState();
            const mastered = isMastered(s);
            const now = Date.now();
            const elapsed = s.lastReview > 0 ? (now - s.lastReview) / (24 * 60 * 60 * 1000) : 0;
            const r = s.stability > 0 ? retrievability(elapsed, s.stability) : 0;
            const label = m === 'enToRu' ? 'EN → RU' : m === 'ruToEn' ? 'RU → EN' : 'Ctx';
            return (
              <div key={m} className="flex items-center justify-between py-1 text-xs">
                <span className="text-text-secondary">{label}</span>
                <div className="flex items-center gap-2 font-mono text-[10px] text-text-muted">
                  <span>R:{(r * 100).toFixed(0)}%</span>
                  <span>S:{s.stability.toFixed(1)}д</span>
                  {mastered && <span className="text-success">✓</span>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Attempts */}
        <div className="text-[9px] tracking-widest uppercase text-text-muted mb-2">История ({attempts.length})</div>
        {attempts.length === 0 ? (
          <div className="text-center py-6 text-text-muted text-xs">Нет попыток</div>
        ) : (
          <div className="space-y-1">
            {attempts.slice(0, 20).map((a, i) => {
              const d = new Date(a.timestamp);
              const dateStr = d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
              const rt = ((a.responseTime || 0) / 1000).toFixed(1);
              return (
                <div key={i} className="bg-bg-elevated rounded-lg p-2 flex items-center gap-2 text-xs">
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${a.correct ? 'bg-success' : 'bg-error'}`} />
                  <div className="flex-1 min-w-0">
                    <div className="truncate">{a.userAnswer}</div>
                    <div className="text-[9px] text-text-muted">{modeLabel(a.mode)} · {dateStr}</div>
                  </div>
                  <div className="font-mono text-[10px] text-text-muted">{rt}с</div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
