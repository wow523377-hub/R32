import { useState, useEffect, useRef, useCallback } from 'react';
import { WordRecord, idbGetAll, idbPut, idbAdd, bumpDailyActivity, getNewWordsLimit, getTodayNewWordIds, recomputeUserStats, AttemptRecord } from '../db';
import { createInitialFSRSState, updateFSRS, retrievability, masteryProgress, Grade } from '../utils/fsrs';
import { playCorrect, playWrong, playTap, playMastery, speak, preloadVoices } from '../utils/audio';

type LearningMode = 'enToRu' | 'ruToEn' | 'context';
type ManualMode = 'auto' | 'en-ru' | 'ru-en' | 'context';

interface Challenge {
  word: WordRecord;
  mode: LearningMode;
  retrievability: number;
  stability: number;
  difficulty: number;
  score: number;
}

let recentWordIds: string[] = [];
let todayNewWordsCache: { date: string; ids: Set<string> } | null = null;

function modeFromManual(m: ManualMode): LearningMode | null {
  if (m === 'en-ru') return 'enToRu';
  if (m === 'ru-en') return 'ruToEn';
  if (m === 'context') return 'context';
  return null;
}

function modeLabel(mode: LearningMode): string {
  if (mode === 'enToRu') return 'EN → RU';
  if (mode === 'ruToEn') return 'RU → EN';
  return 'Context';
}

async function pickNextChallenge(manualMode: ManualMode): Promise<Challenge | null | { limitReached: true }> {
  const words = await idbGetAll('words') as WordRecord[];
  if (!words.length) return null;
  const now = Date.now();

  const newWordsLimit = await getNewWordsLimit();
  const today = new Date().toISOString().slice(0, 10);
  if (!todayNewWordsCache || todayNewWordsCache.date !== today) {
    const ids = await getTodayNewWordIds();
    todayNewWordsCache = { date: today, ids };
  }
  const todayNewIds = todayNewWordsCache.ids;
  const newWordsLeft = Math.max(0, newWordsLimit - todayNewIds.size);

  const forcedMode = manualMode !== 'auto' ? modeFromManual(manualMode) : null;
  const modes: LearningMode[] = forcedMode ? [forcedMode] : ['enToRu', 'ruToEn', 'context'];

  const candidates: Challenge[] = [];

  for (const word of words) {
    if (recentWordIds.includes(word.id) && words.length > 5) continue;

    for (const mode of modes) {
      const srs = word.srs?.[mode] || createInitialFSRSState();
      
      const wordEverStarted = (['enToRu', 'ruToEn', 'context'] as LearningMode[]).some(m =>
        (word.srs?.[m]?.repetitions || 0) > 0
      );
      const isBrandNewToday = !wordEverStarted && !todayNewIds.has(word.id);
      if (isBrandNewToday && newWordsLeft <= 0) continue;

      const elapsedDays = srs.lastReview > 0
        ? (now - srs.lastReview) / (24 * 60 * 60 * 1000)
        : Infinity;
      const r = srs.stability > 0 ? retrievability(elapsedDays, srs.stability) : 0;

      let score = 0;
      if (srs.nextReview > 0 && now > srs.nextReview) {
        const overdueHours = (now - srs.nextReview) / (60 * 60 * 1000);
        score += Math.min(overdueHours / 24, 5) * 0.4;
      }
      if (r < 0.9 && srs.stability > 0) {
        score += (0.9 - r) * 0.3;
      }
      if (srs.repetitions === 0) {
        score += 0.3;
      }
      score += Math.min(srs.lapses, 5) * 0.05;
      score += Math.random() * 0.1;

      candidates.push({
        word,
        mode,
        retrievability: r,
        stability: srs.stability,
        difficulty: srs.difficulty,
        score
      });
    }
  }

  if (!candidates.length) {
    const anyNewBlocked = words.some(w => {
      const started = (['enToRu', 'ruToEn', 'context'] as LearningMode[]).some(m => (w.srs?.[m]?.repetitions || 0) > 0);
      return !started && !todayNewIds.has(w.id);
    });
    if (anyNewBlocked && newWordsLeft <= 0) return { limitReached: true };
    return null;
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates[0];
}

interface LearnScreenProps {
  manualMode: ManualMode;
  onModeChange: (mode: ManualMode) => void;
}

export default function LearnScreen({ manualMode, onModeChange }: LearnScreenProps) {
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [limitReached, setLimitReached] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showGradeButtons, setShowGradeButtons] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false); // Защита от множественных нажатий
  
  const challengeShownAt = useRef(Date.now());
  const inputRef = useRef<HTMLInputElement>(null);
  const loadIdRef = useRef(0); // Для отмены устаревших загрузок
  const manualModeRef = useRef(manualMode); // Актуальное значение для async

  useEffect(() => { manualModeRef.current = manualMode; }, [manualMode]);
  useEffect(() => { preloadVoices(); }, []);

  const loadChallenge = useCallback(async () => {
    const currentLoadId = ++loadIdRef.current;
    const currentMode = manualModeRef.current;
    
    const pick = await pickNextChallenge(currentMode);
    
    // Проверяем, не устарела ли эта загрузка
    if (currentLoadId !== loadIdRef.current) return;
    
    if (!pick || (pick as any).limitReached) {
      setChallenge(null);
      setLimitReached(true);
      return;
    }
    
    setChallenge(pick as Challenge);
    setLimitReached(false);
    setIsAnswered(false);
    setInputValue('');
    setShowGradeButtons(false);
    challengeShownAt.current = Date.now();

    const word = (pick as Challenge).word;
    const everStarted = (['enToRu', 'ruToEn', 'context'] as LearningMode[]).some(m => (word.srs?.[m]?.repetitions || 0) > 0);
    if (!everStarted && todayNewWordsCache) {
      todayNewWordsCache.ids.add(word.id);
    }

    setTimeout(() => inputRef.current?.focus({ preventScroll: true }), 50);
  }, []);

  useEffect(() => { loadChallenge(); }, [manualMode, loadChallenge]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isAnswered || isProcessing || !challenge) return;
    setIsProcessing(true);
    
    const raw = inputValue;
    if (!raw.trim()) {
      setIsProcessing(false);
      return;
    }

    const { word, mode } = challenge;
    
    let correct = false;
    
    if (mode === 'enToRu') {
      const expected = word.russian.toLowerCase().trim();
      const user = raw.toLowerCase().trim();
      correct = expected === user || word.aliases.some(a => {
        const alias = a.toLowerCase().trim();
        return alias === user || levenshtein(user, alias) <= (alias.length <= 4 ? 1 : alias.length <= 9 ? 2 : 3);
      });
    } else {
      const expected = word.english.toLowerCase().trim();
      const user = raw.toLowerCase().trim();
      correct = expected === user || word.aliases.some(a => {
        const alias = a.toLowerCase().trim();
        return alias === user || levenshtein(user, alias) <= (alias.length <= 4 ? 1 : alias.length <= 9 ? 2 : 3);
      });
    }

    const responseTime = Date.now() - challengeShownAt.current;
    const sessId = 's_' + Date.now();

    const attempt: AttemptRecord = {
      wordId: word.id, mode, timestamp: Date.now(),
      correct, userAnswer: raw,
      correctAnswer: mode === 'enToRu' ? word.russian : word.english,
      responseTime, distance: 0, sessionId: sessId
    };
    await idbAdd('attempts', attempt);

    setIsAnswered(true);
    setIsCorrect(correct);
    setCorrectAnswer(mode === 'enToRu' ? word.russian : word.english);
    setShowGradeButtons(true);

    if (soundEnabled) {
      if (correct) playCorrect();
      else playWrong();
    }
    
    setIsProcessing(false);
  };

  const handleGradeSelect = async (selectedGrade: Grade) => {
    if (!challenge || isProcessing) return;
    setIsProcessing(true);
    const { word, mode } = challenge;
    const srs = word.srs?.[mode] || createInitialFSRSState();
    const responseTime = Date.now() - challengeShownAt.current;

    const newSrs = updateFSRS(srs, selectedGrade, responseTime);
    word.srs = { ...(word.srs || {} as any), [mode]: newSrs };
    await idbPut('words', word);

    await bumpDailyActivity(1, selectedGrade >= 2 ? 1 : 0, selectedGrade === 1 ? 1 : 0);
    await recomputeUserStats();

    recentWordIds.push(word.id);
    if (recentWordIds.length > 8) recentWordIds.shift();

    if (soundEnabled && newSrs.stability >= 21 && srs.stability < 21) {
      setTimeout(() => playMastery(), 200);
    }

    setShowGradeButtons(false);
    setChallenge(null);
    setIsProcessing(false);
    loadChallenge();
  };

  const handleModeChange = (mode: ManualMode) => {
    if (soundEnabled) playTap();
    onModeChange(mode);
    // Не вызываем loadChallenge здесь — useEffect сам сработает
  };

  const handleSpeak = (text: string, lang: 'en' | 'ru') => {
    speak(text, lang);
  };

  const p = challenge ? {
    enToRu: masteryProgress(challenge.word.srs?.enToRu || createInitialFSRSState()),
    ruToEn: masteryProgress(challenge.word.srs?.ruToEn || createInitialFSRSState()),
    context: masteryProgress(challenge.word.srs?.context || createInitialFSRSState()),
    total: 0
  } : { enToRu: 0, ruToEn: 0, context: 0, total: 0 };
  p.total = (p.enToRu + p.ruToEn + p.context) / 3;
  
  const circ = 2 * Math.PI * 16;

  if (limitReached) {
    return (
      <div className="animate-fadeIn text-center py-16">
        <div className="text-4xl mb-3">🌙</div>
        <div className="font-serif text-2xl mb-2">На сегодня всё</div>
        <p className="text-text-muted text-sm">Лимит новых слов исчерпан</p>
      </div>
    );
  }

  if (!challenge) {
    return (
      <div className="animate-fadeIn text-center py-16">
        <div className="text-text-muted text-sm">Загрузка...</div>
      </div>
    );
  }

  const { word, mode } = challenge;

  return (
    <div className="animate-fadeIn min-h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-accent/10 border border-accent/20 rounded-full text-xs font-medium text-accent-2">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            {modeLabel(mode)}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary transition-colors">
            {soundEnabled ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <line x1="23" y1="9" x2="17" y2="15" /><line x1="17" y1="9" x2="23" y2="15" />
              </svg>
            )}
          </button>
          <div className="w-9 h-9 relative">
            <svg width="36" height="36" viewBox="0 0 38 38" className="-rotate-90">
              <circle cx="19" cy="19" r="16" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
              <circle cx="19" cy="19" r="16" fill="none" stroke="var(--color-accent)" strokeWidth="3" strokeLinecap="round"
                strokeDasharray={String(circ)} strokeDashoffset={String(circ * (1 - p.total))} className="ring-transition" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-text-muted font-mono">
              {Math.round(p.total * 100)}%
            </div>
          </div>
        </div>
      </div>

      {/* Main content - centered */}
      <div className="flex-1 flex flex-col justify-center">
        {/* Word */}
        <div className="text-center mb-8">
          <div className="text-[10px] tracking-[.2em] uppercase text-text-muted mb-3">
            {mode === 'enToRu' ? 'Переведи на русский' : mode === 'ruToEn' ? 'Переведи на английский' : 'Вставь слово'}
          </div>
          <div className={`font-serif leading-tight font-medium tracking-tight ${mode === 'ruToEn' ? 'text-text-secondary' : 'text-text-primary'} text-4xl md:text-5xl lg:text-6xl`}>
            {mode === 'enToRu' ? word.english : mode === 'ruToEn' ? word.russian : '_____'}
          </div>
        {(mode === 'enToRu' || mode === 'context') && (
          <button
            onClick={() => handleSpeak(word.english, 'en')}
            className="mt-3 inline-flex items-center gap-1 px-2 py-1 rounded text-xs text-text-muted hover:text-accent-2 transition-colors">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
            </svg>
          </button>
        )}
        {mode === 'context' && (
          <div className="mt-3 text-sm text-text-secondary italic">
            {word.context.split('_____').map((part, i, arr) => (
              <span key={i}>
                {part}
                {i < arr.length - 1 && <span className="text-accent-2 font-medium">_____</span>}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Mastery */}
      <div className="flex justify-center gap-4 mb-6">
        {(['enToRu', 'ruToEn', 'context'] as LearningMode[]).map((m, i) => {
          const srs = word.srs?.[m] || createInitialFSRSState();
          const progress = masteryProgress(srs);
          const labels = ['EN→RU', 'RU→EN', 'Ctx'];
          return (
            <div key={m} className="flex flex-col items-center gap-1">
              <div className="flex gap-1">
                {[0, 1, 2].map(j => (
                  <div key={j} className={`w-1.5 h-1.5 rounded-full transition-colors ${progress >= (j + 1) / 3
                    ? 'bg-accent'
                    : 'bg-bg-surface-2'}`} />
                ))}
              </div>
              <div className="text-[9px] text-text-muted">{labels[i]}</div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} autoComplete="off">
        <div className={`bg-bg-elevated border rounded-xl transition-colors ${isAnswered ? (isCorrect ? 'border-success/50' : 'border-error/50') : 'border-white/10 focus-within:border-accent/50'}`}>
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={e => setInputValue(e.target.value)}
            disabled={isAnswered}
            placeholder={mode === 'enToRu' ? 'По-русски…' : mode === 'ruToEn' ? 'In English…' : 'Fill in…'}
            className="w-full py-4 px-4 text-base text-text-primary text-center bg-transparent outline-none placeholder:text-text-faint disabled:opacity-50"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
          />
        </div>
        
        {!isAnswered && (
          <button type="submit" className="w-full mt-4 py-3 rounded-xl font-medium text-sm bg-accent text-accent-ink active:scale-[.98] transition-transform">
            Проверить
          </button>
        )}
      </form>

      {/* Feedback */}
      {isAnswered && (
        <div className={`mt-4 p-3 rounded-xl border animate-fadeIn ${isCorrect ? 'bg-success/5 border-success/20' : 'bg-error/5 border-error/20'}`}>
          <div className={`flex items-center gap-2 font-medium text-sm mb-1 ${isCorrect ? 'text-success' : 'text-error'}`}>
            <span>{isCorrect ? '✓' : '✗'}</span>
            <span>{isCorrect ? 'Правильно!' : 'Неверно'}</span>
          </div>
          {!isCorrect && (
            <div className="text-sm text-text-secondary">
              Ответ: <span className="text-text-primary font-serif">{correctAnswer}</span>
            </div>
          )}
        </div>
      )}

      {/* Grade buttons */}
      {showGradeButtons && (
        <div className="mt-4 grid grid-cols-4 gap-2 animate-fadeIn">
          {([1, 2, 3, 4] as Grade[]).map(g => {
            const colors = ['', 'bg-error/10 border-error/30 text-error', 'bg-warning/10 border-warning/30 text-warning', 'bg-success/10 border-success/30 text-success', 'bg-accent/10 border-accent/30 text-accent-2'];
            const labels = ['', 'Забыл', 'Сложно', 'Норм', 'Легко'];
            return (
              <button key={g} onClick={() => handleGradeSelect(g)}
                className={`py-2.5 rounded-lg text-xs font-medium border transition-colors ${colors[g]}`}>
                {labels[g]}
              </button>
            );
          })}
        </div>
      )}

      </div>

      {/* Current mode indicator */}
      <div className="mt-6 text-center flex-shrink-0">
        <div className="text-xs text-text-muted">
          Mode: <span className="text-accent">{manualMode === 'auto' ? 'Auto (FSRS)' : manualMode === 'en-ru' ? 'EN→RU' : manualMode === 'ru-en' ? 'RU→EN' : 'Context'}</span>
        </div>
        <div className="text-[10px] text-text-faint mt-1">Swipe from left to change mode</div>
      </div>
    </div>
  );
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const m = a.length, n = b.length;
  let prev = new Array(n + 1);
  let curr = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    const ai = a.charCodeAt(i - 1);
    for (let j = 1; j <= n; j++) {
      const cost = ai === b.charCodeAt(j - 1) ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}
