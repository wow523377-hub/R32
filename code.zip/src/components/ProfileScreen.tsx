import { useState, useEffect, useRef } from 'react';
import { WordRecord, AttemptRecord, SessionRecord, idbGetAll, idbGet, getNewWordsLimit, setNewWordsLimit, getTodayNewWordIds, recomputeUserStats, UserStatsRecord, exportAllData, importAllData, downloadJson, ExportPayload } from '../db';
import { createInitialFSRSState, isMastered, masteryProgress } from '../utils/fsrs';

function formatDuration(ms: number): string {
  if (!ms) return '0м';
  const s = Math.round(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h) return `${h}ч ${m}м`;
  return `${m}м`;
}

export default function ProfileScreen({ onOpenWord }: { onOpenWord: (id: string) => void }) {
  const [stats, setStats] = useState<UserStatsRecord | null>(null);
  const [words, setWords] = useState<WordRecord[]>([]);
  const [attempts, setAttempts] = useState<AttemptRecord[]>([]);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [newWordsLimit, setLimit] = useState(10);
  const [todayNewCount, setTodayNewCount] = useState(0);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const w = await idbGetAll('words') as WordRecord[];
      const a = await idbGetAll('attempts') as AttemptRecord[];
      const s = await idbGetAll('sessions') as SessionRecord[];
      const st = (await idbGet('userStats', 'global')) as UserStatsRecord || await recomputeUserStats();
      const limit = await getNewWordsLimit();
      const todayIds = await getTodayNewWordIds();

      setWords(w);
      setAttempts(a);
      setSessions(s);
      setStats(st);
      setLimit(limit);
      setTodayNewCount(todayIds.size);
    } catch (err) {
      console.warn('Failed to load profile data:', err);
    }
  };

  const handleExport = async () => {
    try {
      const data = await exportAllData();
      const date = new Date().toISOString().slice(0, 10);
      downloadJson(data, `31dec-backup-${date}.json`);
      setImportStatus('✅ Бэкап сохранён');
    } catch (err) {
      console.warn('Export failed:', err);
      setImportStatus('❌ Ошибка');
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const payload = JSON.parse(text) as ExportPayload;
      // Валидация структуры
      if (!payload || !payload.stores || typeof payload.stores !== 'object') {
        throw new Error('Invalid backup format');
      }
      const result = await importAllData(payload, 'merge');
      setImportStatus(`✅ ${result.wordsMerged} слов, ${result.attemptsAdded} попыток`);
      await loadData();
    } catch (err) {
      console.warn('Import failed:', err);
      setImportStatus('❌ Ошибка импорта');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Очистка importStatus timeout при размонтировании
  useEffect(() => {
    if (!importStatus) return;
    const timer = setTimeout(() => setImportStatus(null), 3000);
    return () => clearTimeout(timer);
  }, [importStatus]);

  if (!stats) return <div className="animate-fadeIn text-center py-16 text-text-muted text-sm">Загрузка...</div>;

  const totalProgress = words.length > 0
    ? words.reduce((sum, w) => {
        const modes = ['enToRu', 'ruToEn', 'context'] as const;
        const prog = modes.reduce((s, m) => s + masteryProgress(w.srs?.[m] || createInitialFSRSState()), 0) / 3;
        return sum + prog;
      }, 0) / words.length
    : 0;

  const mastered = words.filter(w => (['enToRu', 'ruToEn', 'context'] as const).every(m => isMastered(w.srs?.[m] || createInitialFSRSState()))).length;
  const pct = Math.round(totalProgress * 100);
  const circ = 2 * Math.PI * 56;

  const modes = ['enToRu', 'ruToEn', 'context'] as const;
  const accData = modes.map(mode => {
    const list = attempts.filter(a => a.mode === mode);
    const total = list.length;
    const correct = list.filter(a => a.correct).length;
    return { mode, total, correct, pct: total ? correct / total : 0 };
  });
  const allTotal = attempts.length;
  const allCorrect = attempts.filter(a => a.correct).length;
  const allPct = allTotal ? allCorrect / allTotal : 0;

  const hardWords = words.map(w => {
    const wa = attempts.filter(a => a.wordId === w.id);
    if (!wa.length) return null;
    const total = wa.length;
    const correct = wa.filter(a => a.correct).length;
    const wrong = total - correct;
    const errorRate = wrong / total;
    const srs = w.srs?.enToRu || createInitialFSRSState();
    const score = errorRate * 0.5 + Math.min(1, total / 15) * 0.2 + (3 - srs.stability / 10) * 0.3;
    return { w, total, correct, wrong, score };
  }).filter(Boolean).sort((a, b) => b!.score - a!.score).slice(0, 5);

  const handleLimitChange = async (v: number) => {
    setLimit(v);
    await setNewWordsLimit(v);
    const ids = await getTodayNewWordIds();
    setTodayNewCount(ids.size);
  };

  return (
    <div className="animate-fadeIn">
      {/* Hero */}
      <div className="flex items-center gap-4 p-4 md:p-5 lg:p-6 bg-bg-elevated border border-white/5 rounded-xl mb-4">
        <div className="w-20 h-20 md:w-24 md:h-24 lg:w-28 lg:h-28 flex-shrink-0 relative">
          <svg viewBox="0 0 130 130" className="w-full h-full -rotate-90">
            <circle cx="65" cy="65" r="56" fill="none" stroke="var(--color-bg-surface-2)" strokeWidth="8" />
            <circle cx="65" cy="65" r="56" fill="none" stroke="var(--color-accent)" strokeWidth="8" strokeLinecap="round"
              strokeDasharray="351.86" strokeDashoffset={String(circ * (1 - totalProgress))} className="ring-transition" />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-serif text-2xl md:text-3xl lg:text-4xl font-medium">{pct}%</div>
            <div className="text-[8px] md:text-[9px] text-text-muted uppercase tracking-wider">Усвоено</div>
          </div>
        </div>
        <div className="flex-1">
          <div className="text-sm md:text-base lg:text-lg font-medium mb-0.5">
            {mastered} из {words.length} слов
          </div>
          <div className="text-xs md:text-sm text-text-muted">
            {stats.totalAttempts === 0 ? 'Начни первую сессию' : `${stats.totalAttempts} попыток`}
          </div>
        </div>
      </div>

      {/* Streak */}
      <div className="flex items-center gap-3 p-3 bg-bg-elevated border border-white/5 rounded-xl mb-4">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#e87848] to-[#f2b157] flex items-center justify-center">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff">
            <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" />
          </svg>
        </div>
        <div>
          <div className="font-serif text-xl font-medium">{stats.currentStreak || 0}</div>
          <div className="text-[10px] text-text-muted uppercase tracking-wider">дней подряд</div>
        </div>
        <div className="ml-auto text-right">
          <div className="font-mono text-sm text-text-secondary">{stats.maxStreak || 0}</div>
          <div className="text-[9px] text-text-muted uppercase tracking-wider">Рекорд</div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2 mb-4">
        {[
          { val: formatDuration(stats.totalDuration || 0), label: 'Время' },
          { val: String(stats.totalSessions || 0), label: 'Сессий' },
          { val: String(stats.totalAttempts || 0), label: 'Заданий' },
          { val: `${mastered}/${words.length}`, label: 'Усвоено' }
        ].map((s, i) => (
          <div key={i} className="bg-bg-elevated border border-white/5 rounded-xl p-2.5 text-center">
            <div className="font-serif text-lg font-medium">{s.val}</div>
            <div className="text-[9px] text-text-muted uppercase tracking-wider">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Accuracy */}
      <div className="bg-bg-elevated border border-white/5 rounded-xl p-3 mb-4">
        <div className="text-[10px] font-semibold tracking-widest uppercase text-text-muted mb-2">Точность</div>
        {[...accData.map(a => ({ label: a.mode === 'enToRu' ? 'EN → RU' : a.mode === 'ruToEn' ? 'RU → EN' : 'Context', pct: a.pct, total: a.total })),
          { label: 'Общая', pct: allPct, total: allTotal }
        ].map((row, i) => {
          const pctStr = row.total ? (row.pct * 100).toFixed(0) + '%' : '0';
          const valStr = row.total ? Math.round(row.pct * 100) + '%' : '—';
          return (
            <div key={i} className={`flex items-center gap-2 py-1.5 ${i > 0 ? 'border-t border-white/5' : ''}`}>
              <div className="w-14 text-xs text-text-secondary">{row.label}</div>
              <div className="flex-1 h-1 bg-bg-surface-2 rounded-full overflow-hidden">
                <div className="h-full bg-accent rounded-full transition-all" style={{ width: pctStr }} />
              </div>
              <div className="w-10 text-right font-mono text-xs">{valStr}</div>
            </div>
          );
        })}
      </div>

      {/* Backup */}
      <div className="bg-bg-elevated border border-white/5 rounded-xl p-3 mb-4">
        <div className="text-[10px] font-semibold tracking-widest uppercase text-text-muted mb-2">Бэкап</div>
        <div className="flex gap-2">
          <button onClick={handleExport} className="flex-1 py-2 rounded-lg text-xs font-medium bg-bg-surface-2 text-text-primary border border-white/5">
            Экспорт
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="flex-1 py-2 rounded-lg text-xs font-medium bg-accent text-accent-ink">
            Импорт
          </button>
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
        </div>
        {importStatus && <div className="mt-2 text-xs text-text-secondary">{importStatus}</div>}
      </div>

      {/* New words limit */}
      <div className="bg-bg-elevated border border-white/5 rounded-xl p-3 mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[10px] font-semibold tracking-widest uppercase text-text-muted">Новые слова</div>
          <div className="font-serif text-lg text-accent-2">{newWordsLimit}</div>
        </div>
        <input type="range" min="5" max="25" step="1" value={newWordsLimit}
          onChange={e => handleLimitChange(parseInt(e.target.value))} />
        <div className="flex justify-between text-[9px] text-text-muted mt-1">
          <span>5</span><span>25</span>
        </div>
      </div>

      {/* Hard words */}
      {hardWords.length > 0 && (
        <div className="mb-4">
          <div className="text-[10px] font-semibold tracking-widest uppercase text-text-muted mb-2">Сложные слова</div>
          <div className="space-y-1.5">
            {hardWords.map(item => {
              if (!item) return null;
              const accPct = item.total ? Math.round(item.correct / item.total * 100) : 0;
              return (
                <div key={item.w.id} onClick={() => onOpenWord(item.w.id)}
                  className="bg-bg-elevated border border-white/5 rounded-xl p-2.5 flex items-center justify-between cursor-pointer active:bg-bg-surface">
                  <div className="font-serif text-sm">{item.w.english}</div>
                  <div className="font-mono text-xs text-error">{accPct}%</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Categories */}
      <div className="mb-4">
        <div className="text-[10px] font-semibold tracking-widest uppercase text-text-muted mb-2">Категории</div>
        <div className="bg-bg-elevated border border-white/5 rounded-xl overflow-hidden">
          {[
            { key: 'Nouns', name: 'Существительные', icon: 'N' },
            { key: 'Verbs', name: 'Глаголы', icon: 'V' },
            { key: 'At the table', name: 'За столом', icon: 'T' },
            { key: 'Morning Jan 1', name: 'Утро 1 янв', icon: 'M' }
          ].map((cat, i) => {
            const cw = words.filter(w => w.category === cat.key);
            if (!cw.length) return null;
            const p = cw.reduce((s, w) => {
              const modes = ['enToRu', 'ruToEn', 'context'] as const;
              return s + modes.reduce((sum, m) => sum + masteryProgress(w.srs?.[m] || createInitialFSRSState()), 0) / 3;
            }, 0) / cw.length;
            return (
              <div key={cat.key} className={`flex items-center gap-2 p-2.5 ${i > 0 ? 'border-t border-white/5' : ''}`}>
                <div className="w-7 h-7 rounded-lg bg-bg-surface-2 flex items-center justify-center text-accent-2 text-xs">{cat.icon}</div>
                <div className="flex-1 text-xs">{cat.name}</div>
                <div className="font-mono text-xs text-accent-2">{Math.round(p * 100)}%</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
