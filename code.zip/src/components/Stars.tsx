import { useEffect, useRef } from 'react';

export default function Stars() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const container = ref.current;
    for (let i = 0; i < 20; i++) {
      const s = document.createElement('div');
      s.className = 'star';
      s.style.left = (Math.random() * 100) + '%';
      s.style.top = (Math.random() * 100) + '%';
      s.style.animationDelay = (Math.random() * 4) + 's';
      container.appendChild(s);
    }
    return () => { container.innerHTML = ''; };
  }, []);

  return <div ref={ref} className="fixed inset-0 pointer-events-none z-0" />;
}
