import { useRef, useEffect, useCallback } from 'react';

type ManualMode = 'auto' | 'en-ru' | 'ru-en' | 'context';

interface SidebarProps {
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
  activeMode: ManualMode;
  onModeChange: (mode: ManualMode) => void;
  onNavigate: (screen: 'learn' | 'profile' | 'settings') => void;
  currentScreen: 'learn' | 'profile' | 'settings';
}

export default function Sidebar({ isOpen, onOpen, onClose, activeMode, onModeChange, onNavigate, currentScreen }: SidebarProps) {
  const sidebarRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);
  const isOpenRef = useRef(isOpen);
  const sidebarWidthRef = useRef(360);
  
  // Drag state в ref для избежания race conditions
  const dragRef = useRef({
    isDragging: false,
    startX: 0,
    currentX: 0,
    velocity: 0,
    lastTime: 0,
    pointerId: -1
  });

  // Синхронизация refs
  useEffect(() => { isOpenRef.current = isOpen; }, [isOpen]);
  
  useEffect(() => {
    const updateWidth = () => {
      sidebarWidthRef.current = Math.min(window.innerWidth * 0.88, 360);
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  // Pointer handlers - стабильные функции без зависимостей от state
  const handlePointerDown = useCallback((e: PointerEvent) => {
    const isEdgeSwipe = e.clientX < 50;
    const isOnSidebar = sidebarRef.current?.contains(e.target as Node);
    
    if (!isEdgeSwipe && !isOnSidebar) return;
    if (isOnSidebar && !isOpenRef.current) return;

    // Предотвращаем скролл только при открытии
    if (isEdgeSwipe && !isOpenRef.current) {
      e.preventDefault();
    }

    dragRef.current = {
      isDragging: true,
      startX: e.clientX,
      currentX: e.clientX,
      velocity: 0,
      lastTime: Date.now(),
      pointerId: e.pointerId
    };

    // Отключаем CSS transition во время drag
    if (sidebarRef.current) {
      sidebarRef.current.style.transition = 'none';
    }
  }, []);

  const handlePointerMove = useCallback((e: PointerEvent) => {
    const drag = dragRef.current;
    if (!drag.isDragging) return;

    const now = Date.now();
    const deltaTime = now - drag.lastTime;
    const deltaX = e.clientX - drag.currentX;
    const velocity = deltaTime > 0 ? deltaX / deltaTime : 0;
    
    drag.currentX = e.clientX;
    drag.velocity = velocity;
    drag.lastTime = now;

    const sidebarWidth = sidebarWidthRef.current;
    const totalDeltaX = e.clientX - drag.startX;

    // Update sidebar position напрямую через DOM
    if (sidebarRef.current) {
      let translateX: number;
      
      if (isOpenRef.current) {
        // Closing: sidebar moves left
        translateX = Math.min(0, Math.max(-sidebarWidth, totalDeltaX));
      } else {
        // Opening: sidebar moves right from -sidebarWidth to 0
        translateX = Math.min(0, Math.max(-sidebarWidth, e.clientX - sidebarWidth));
      }
      
      sidebarRef.current.style.transform = `translateX(${translateX}px)`;
    }

    // Update backdrop opacity
    if (backdropRef.current) {
      let progress: number;
      if (isOpenRef.current) {
        const translateX = Math.min(0, Math.max(-sidebarWidth, totalDeltaX));
        progress = 1 - Math.abs(translateX) / sidebarWidth;
      } else {
        progress = Math.max(0, Math.min(1, e.clientX / sidebarWidth));
      }
      backdropRef.current.style.opacity = String(progress * 0.6);
    }
  }, []);

  const handlePointerUp = useCallback(() => {
    const drag = dragRef.current;
    if (!drag.isDragging) return;

    const deltaX = drag.currentX - drag.startX;
    const absVelocity = Math.abs(drag.velocity);
    const sidebarWidth = sidebarWidthRef.current;
    
    // Threshold 20% или velocity > 0.3
    const shouldOpen = deltaX > sidebarWidth * 0.2 || absVelocity > 0.3;
    const shouldClose = deltaX < -sidebarWidth * 0.2 || absVelocity > 0.3;

    // Восстанавливаем CSS transition
    if (sidebarRef.current) {
      sidebarRef.current.style.transition = '';
    }

    if (shouldOpen && !isOpenRef.current) {
      onOpen();
    } else if (shouldClose && isOpenRef.current) {
      onClose();
    } else {
      // Возврат в текущее состояние
      if (sidebarRef.current) {
        sidebarRef.current.style.transform = isOpenRef.current ? 'translateX(0)' : 'translateX(-100%)';
      }
      if (backdropRef.current) {
        backdropRef.current.style.opacity = isOpenRef.current ? '0.6' : '0';
      }
    }

    // Сбрасываем drag state
    dragRef.current = {
      isDragging: false,
      startX: 0,
      currentX: 0,
      velocity: 0,
      lastTime: 0,
      pointerId: -1
    };
  }, [onOpen, onClose]);

  // Attach pointer events - один раз при mount
  useEffect(() => {
    const sidebar = sidebarRef.current;
    if (!sidebar) return;

    // Используем document для move/up чтобы ловить события за пределами sidebar
    document.addEventListener('pointermove', handlePointerMove);
    document.addEventListener('pointerup', handlePointerUp);
    document.addEventListener('pointercancel', handlePointerUp);

    // Edge swipe zone
    const handleEdgeDown = (e: PointerEvent) => {
      if (e.clientX < 50 && !isOpenRef.current) {
        handlePointerDown(e);
      }
    };
    document.addEventListener('pointerdown', handleEdgeDown);

    // Sidebar swipe (для закрытия)
    const handleSidebarDown = (e: PointerEvent) => {
      if (isOpenRef.current) {
        handlePointerDown(e);
      }
    };
    sidebar.addEventListener('pointerdown', handleSidebarDown);

    return () => {
      document.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('pointerup', handlePointerUp);
      document.removeEventListener('pointercancel', handlePointerUp);
      document.removeEventListener('pointerdown', handleEdgeDown);
      sidebar.removeEventListener('pointerdown', handleSidebarDown);
    };
  }, [handlePointerDown, handlePointerMove, handlePointerUp]);

  // Update position when isOpen changes (без drag)
  useEffect(() => {
    // Не обновляем позицию во время drag
    if (dragRef.current.isDragging) return;
    
    if (sidebarRef.current) {
      sidebarRef.current.style.transition = '';
      sidebarRef.current.style.transform = isOpen ? 'translateX(0)' : 'translateX(-100%)';
    }
    if (backdropRef.current) {
      backdropRef.current.style.opacity = isOpen ? '0.6' : '0';
    }
  }, [isOpen]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpenRef.current) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleModeSelect = (mode: ManualMode) => {
    onModeChange(mode);
    onNavigate('learn');
    onClose();
  };

  const modes: { mode: ManualMode; title: string; subtitle: string }[] = [
    { mode: 'auto', title: 'AUTO', subtitle: 'FSRS algorithm' },
    { mode: 'en-ru', title: 'EN → RU', subtitle: 'English → Russian' },
    { mode: 'ru-en', title: 'RU → EN', subtitle: 'Russian → English' },
    { mode: 'context', title: 'CONTEXT', subtitle: 'Fill in the blank' }
  ];

  return (
    <>
      {/* Swipe edge indicator */}
      <div className="swipe-edge" aria-hidden="true" />

      {/* Backdrop */}
      <div
        ref={backdropRef}
        className="sidebar-backdrop"
        onClick={() => isOpen && onClose()}
        aria-hidden="true"
      />

      {/* Sidebar */}
      <aside
        ref={sidebarRef}
        className="sidebar"
        role="dialog"
        aria-modal={isOpen}
        aria-label="Navigation menu"
      >
        <div className="h-full flex flex-col overflow-y-auto">
          {/* Header */}
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="font-serif text-2xl font-medium text-text-primary">31.Dec</h1>
                <p className="text-xs text-text-muted mt-1">New Year English</p>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-surface transition-colors"
                aria-label="Close menu"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M18 6L6 18" /><path d="M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="text-xs text-text-muted">
              Swipe from left edge to open
            </div>
          </div>

          {/* Modes */}
          <div className="p-6 flex-1">
            <div className="text-xs font-semibold tracking-widest uppercase text-text-muted mb-4">
              Learning Modes
            </div>
            <div className="space-y-3">
              {modes.map(({ mode, title, subtitle }) => (
                <button
                  key={mode}
                  onClick={() => handleModeSelect(mode)}
                  className={`mode-card w-full text-left ${activeMode === mode ? 'active' : ''}`}
                >
                  <div className="mode-title font-serif text-xl font-medium text-text-primary mb-1">
                    {title}
                  </div>
                  <div className="text-sm text-text-secondary">{subtitle}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="p-6 border-t border-border">
            <div className="space-y-2">
              <button
                onClick={() => { onNavigate('learn'); onClose(); }}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  currentScreen === 'learn' ? 'text-accent' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                Learn
              </button>
              <button
                onClick={() => { onNavigate('profile'); onClose(); }}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  currentScreen === 'profile' ? 'text-accent' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                Profile
              </button>
              <button
                onClick={() => { onNavigate('settings'); onClose(); }}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  currentScreen === 'settings' ? 'text-accent' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                Settings
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
